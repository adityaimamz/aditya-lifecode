import "regenerator-runtime";
import "axios"
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.min.js";
import "./styles/main.css";
import main from "./scripts/view/main";

main();